<?php session_start(); ?>
<h2>Welcome and enjoy it mister or miss <?php echo $_SESSION['email']?></h2>