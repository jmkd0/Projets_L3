<!DOCTYPE html>
<html>
 <head>
 <meta charset="utf-8"/>
<link rel="stylesheet" href="style.css" >
 <title>Contactez nous</title>
 </head>
 <body>
 <!-- L'en-t�te -->
 <?php include("head.php"); ?>

<div style="background-color:white">
	 <div id="corps">
 <h1 style="color:black; font-family:Old English Text MT; text-align:center; ">Bienvenue dans votre magasin </h1>
</div>
<div id="corps">
 <h1></h1>
<!--Connection au compte-->

<div>
<form  style="margin:0px 40% 0px 30%;" action="insertion.php" method="post">
	<h2>Connectez-nous</h2>
<fieldset >
	<img src="images/up8.png" alt="contacter" width="100" height="80">
<h2>Université Paris 8:</h2>
<h2>Pour nous contacter pour des raisons de maintenance et d'accès à la plateforme</h2>
<h2>Vous pouvez nous joindre par:</h2>
<h3>Komlan au: +33 (0) 7 83 67 18 02 <br>
	<br>
	<br>
<br><br>Ou par courriel: jmkd@yahoo.com</h3>


</fieldset>
</form>

<br><br><br><br><br><br><br><br><br><br>

</div>
 </body>
 
 <?php include("foot.php"); ?>
</html>



